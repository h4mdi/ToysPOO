create
    definer = root@localhost procedure GetSalesByPerson(IN startDate date, IN endDate date)
SELECT o.SalesPersonId ,SUM(od.Quantity*od.UnitPrice)
FROM orderdetails od 
JOIN orders o ON od.OrderId = o.Id
WHERE o.IsValid=1
AND (startDate is null OR startDate<=o.Date)
AND (endDate is null OR endDate>=o.Date)
GROUP BY od.OrderId;

