create
    definer = root@localhost procedure GetSalesByToy(IN startDate date, IN endDate date)
SELECT tt.Name,SUM(od.Quantity*od.UnitPrice)
FROM orders o
JOIN orderdetails od on o.Id=od.OrderId
JOIN toys t on t.Id = od.TotyId 
JOIN toytypes tt on t.TypeId = tt.Id
WHERE o.IsValid=1
AND (startDate is null OR startDate<=o.Date)
AND (endDate is null OR endDate>=o.Date)
GROUP BY tt.Name
ORDER BY tt.Name;

